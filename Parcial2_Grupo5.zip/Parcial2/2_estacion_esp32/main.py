# main.py  -  ESP32-S3 "ESTACION" (MicroPython)
# Banda transportadora + compuerta de inspección + selector en cadena de vasos
# + empujador hacia el carro + celda de carga. Servidor HTTP por Wi-Fi.
#
# Flujo:
#   1. La banda (28BYJ-48) avanza hasta que el sensor IR detecta una moneda
#      bajo la cámara; la compuerta (servo) la retiene.
#   2. El PC (vision_monedas.py) la identifica y llama  /moneda?valor=500
#   3. La cadena (NEMA 17 + A4988) gira hasta dejar el vaso de $500 bajo la caída.
#   4. La compuerta se abre, la banda lleva la moneda al final y cae en su vaso.
#   5. /entregar?valor=500 lleva ese vaso al puesto de entrega, lo pesa (HX711)
#      y el empujador (servo) lo pasa al porta-vaso del carro.
#
# Rutas HTTP:  /estado   /moneda?valor=V   /entregar?valor=V   /home   /tara

import asyncio
import json
import time
import network
from machine import Pin, PWM

# ------------------------------------------------------------------ CONFIGURACION
WIFI_SSID = "MI_RED"
WIFI_CLAVE = "MI_CLAVE"
AP_SSID, AP_CLAVE = "Estacion-Monedas", "12345678"   # si no hay red, crea su propio Wi-Fi

PINES_BANDA = (4, 5, 6, 7)        # ULN2003 IN1..IN4 (28BYJ-48)
PIN_STEP, PIN_DIR, PIN_EN = 15, 16, 17    # A4988 de la cadena (NEMA 17)
PIN_HOME_CADENA = 18              # sensor optico TCRT5000 en el puesto 0 (activo en bajo)
PIN_SENSOR_MONEDA = 1             # sensor IR FC-51 bajo la camara (activo en bajo)
PIN_SERVO_COMPUERTA = 10
PIN_SERVO_EMPUJADOR = 13
PIN_HX711_DT, PIN_HX711_SCK = 11, 12

PUESTOS = [50, 100, 200, 500, 1000, "rechazo"]   # orden de los vasos en la cadena
PUESTO_ENTREGA = 3                # la entrega esta 3 puestos despues de la caida
DIST_VASOS_MM, DIAM_PINON_MM, MICROPASOS = 195, 40, 8
PASOS_POR_PUESTO = int(DIST_VASOS_MM / (3.1416 * DIAM_PINON_MM) * 200 * MICROPASOS)   # = 2483
PASOS_VUELTA = PASOS_POR_PUESTO * len(PUESTOS)
T_CAIDA_MS = 4500                 # banda ~19 mm/s: la camara esta a 75 mm del final
T_SIN_VISION_MS = 5000            # si el PC no responde, la moneda va a "rechazo"
PESOS = {50: 2.00, 100: 3.34, 200: 4.61, 500: 7.14, 1000: 9.95}   # gramos
ESCALA_HX711 = 420.0              # cuentas por gramo (calibrar con un peso conocido)


# ------------------------------------------------------------------ ACTUADORES
class PasoAPaso28BYJ:
    SECUENCIA = ((1, 0, 0, 0), (1, 1, 0, 0), (0, 1, 0, 0), (0, 1, 1, 0),
                 (0, 0, 1, 0), (0, 0, 1, 1), (0, 0, 0, 1), (1, 0, 0, 1))

    def __init__(self, pines):
        self.bobinas = [Pin(n, Pin.OUT, value=0) for n in pines]
        self.i = 0

    def paso(self):
        self.i = (self.i + 1) % 8
        for b, v in zip(self.bobinas, self.SECUENCIA[self.i]):
            b.value(v)

    def liberar(self):
        for b in self.bobinas:
            b.value(0)


class PasoAPasoA4988:
    def __init__(self, step, dire, en):
        self.step = Pin(step, Pin.OUT, value=0)
        self.dir = Pin(dire, Pin.OUT, value=0)
        self.en = Pin(en, Pin.OUT, value=1)       # 1 = deshabilitado
        self.posicion = 0                          # pasos (0 = vaso de $50 en la caida)

    async def mover(self, pasos, us_min=350, us_max=1400):
        """Movimiento con rampa trapezoidal (arranca y frena suave)."""
        if pasos == 0:
            return
        self.en.value(0)
        self.dir.value(1 if pasos > 0 else 0)
        n = abs(pasos)
        rampa = min(300, n // 2)
        for k in range(n):
            d = min(k, n - 1 - k)
            us = us_max - (us_max - us_min) * min(d, rampa) // max(rampa, 1)
            self.step.value(1)
            time.sleep_us(4)
            self.step.value(0)
            time.sleep_us(us)
            if k % 200 == 0:
                await asyncio.sleep_ms(0)          # deja atender al servidor web
        self.posicion = (self.posicion + pasos) % PASOS_VUELTA
        self.en.value(1)


class Servo:
    def __init__(self, pin, angulo=0):
        self.pwm = PWM(Pin(pin), freq=50)
        self.angulo(angulo)

    def angulo(self, a):
        us = 500 + 2000 * max(0, min(180, a)) // 180
        self.pwm.duty_u16(us * 65535 // 20000)


class HX711:
    def __init__(self, dt, sck):
        self.dt = Pin(dt, Pin.IN)
        self.sck = Pin(sck, Pin.OUT, value=0)
        self.cero = 0

    def crudo(self):
        t0 = time.ticks_ms()
        while self.dt.value():
            if time.ticks_diff(time.ticks_ms(), t0) > 200:
                return None                     # sin celda conectada
        v = 0
        for _ in range(24):
            self.sck.value(1)
            v = (v << 1) | self.dt.value()
            self.sck.value(0)
        self.sck.value(1)                       # pulso 25: ganancia 128
        self.sck.value(0)
        if v & 0x800000:
            v -= 1 << 24
        return v

    def promedio(self, n=8):
        datos = [x for x in (self.crudo() for _ in range(n)) if x is not None]
        return sum(datos) / len(datos) if datos else None

    def tara(self):
        v = self.promedio(16)
        self.cero = v if v is not None else 0

    def gramos(self):
        v = self.promedio()
        return None if v is None else round((v - self.cero) / ESCALA_HX711, 2)


# ------------------------------------------------------------------ ESTADO
banda = PasoAPaso28BYJ(PINES_BANDA)
cadena = PasoAPasoA4988(PIN_STEP, PIN_DIR, PIN_EN)
home_cadena = Pin(PIN_HOME_CADENA, Pin.IN, Pin.PULL_UP)
sensor_moneda = Pin(PIN_SENSOR_MONEDA, Pin.IN, Pin.PULL_UP)
compuerta = Servo(PIN_SERVO_COMPUERTA, 0)        # 0 = cerrada, 90 = abierta
empujador = Servo(PIN_SERVO_EMPUJADOR, 0)        # 0 = recogido, 120 = empuja
balanza = HX711(PIN_HX711_DT, PIN_HX711_SCK)

estado = {
    "estado": "BANDA",            # BANDA, ESPERANDO_VISION, CLASIFICANDO, ENTREGANDO
    "conteo": {str(v): 0 for v in PESOS},
    "rechazadas": 0,
    "vasos": {str(v): {"monedas": 0, "valor": 0, "peso": 0.0} for v in PUESTOS},
    "ultima": None,
    "peso_medido_g": None,
    "ip": "",
}
t_espera = 0
ocupado = False


def resumen():
    total = sum(int(k) * n for k, n in estado["conteo"].items())
    peso = sum(PESOS[int(k)] * n for k, n in estado["conteo"].items())
    r = dict(estado)
    r["valor_total"] = total
    r["peso_total_g"] = round(peso, 2)
    r["monedas_total"] = sum(estado["conteo"].values())
    return r


async def ir_a_puesto(indice_vaso, puesto):
    """Gira la cadena para que el vaso 'indice_vaso' quede en 'puesto' (camino mas corto)."""
    objetivo = ((puesto - indice_vaso) * PASOS_POR_PUESTO) % PASOS_VUELTA
    delta = (objetivo - cadena.posicion + PASOS_VUELTA // 2) % PASOS_VUELTA - PASOS_VUELTA // 2
    await cadena.mover(delta)


async def clasificar(valor):
    """Lleva el vaso correcto a la caida y suelta la moneda."""
    global ocupado
    ocupado = True
    estado["estado"] = "CLASIFICANDO"
    etiqueta = valor if valor in PESOS else "rechazo"
    await ir_a_puesto(PUESTOS.index(etiqueta), 0)
    compuerta.angulo(90)                          # abre la compuerta
    t0 = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), t0) < T_CAIDA_MS:
        banda.paso()
        if time.ticks_diff(time.ticks_ms(), t0) > 800:
            compuerta.angulo(0)                   # la cierra para la siguiente
        await asyncio.sleep_ms(1)
    v = estado["vasos"][str(etiqueta)]
    v["monedas"] += 1
    if etiqueta == "rechazo":
        estado["rechazadas"] += 1
    else:
        estado["conteo"][str(etiqueta)] += 1
        v["valor"] += etiqueta
        v["peso"] = round(v["peso"] + PESOS[etiqueta], 2)
    estado["ultima"] = {"valor": valor, "t": time.ticks_ms()}
    estado["estado"] = "BANDA"
    ocupado = False


async def entregar(valor):
    """Lleva el vaso al puesto de entrega, lo pesa y lo empuja al carro."""
    global ocupado
    ocupado = True
    estado["estado"] = "ENTREGANDO"
    etiqueta = valor if valor in PESOS else "rechazo"
    await ir_a_puesto(PUESTOS.index(etiqueta), PUESTO_ENTREGA)
    await asyncio.sleep_ms(500)
    estado["peso_medido_g"] = balanza.gramos()
    for a in range(0, 121, 4):                    # empuje suave
        empujador.angulo(a)
        await asyncio.sleep_ms(25)
    await asyncio.sleep_ms(400)
    empujador.angulo(0)
    estado["vasos"][str(etiqueta)] = {"monedas": 0, "valor": 0, "peso": 0.0}   # vaso nuevo vacio
    estado["estado"] = "BANDA"
    ocupado = False


async def hacer_home():
    global ocupado
    ocupado = True
    estado["estado"] = "HOME"
    cadena.en.value(0)
    cadena.dir.value(0)
    for _ in range(PASOS_VUELTA + PASOS_POR_PUESTO):
        if home_cadena.value() == 0:
            break
        cadena.step.value(1)
        time.sleep_us(4)
        cadena.step.value(0)
        time.sleep_us(1200)
    cadena.en.value(1)
    cadena.posicion = 0
    estado["estado"] = "BANDA"
    ocupado = False


# ------------------------------------------------------------------ TAREAS
async def tarea_banda():
    """Avanza la banda hasta que una moneda llega a la zona de inspeccion."""
    global t_espera
    while True:
        if estado["estado"] == "BANDA" and not ocupado:
            if sensor_moneda.value() == 0:            # moneda bajo la camara
                banda.liberar()
                estado["estado"] = "ESPERANDO_VISION"
                t_espera = time.ticks_ms()
            else:
                banda.paso()
            await asyncio.sleep_ms(1)                 # 1 ms por medio paso: ~19 mm/s con rodillo de 25 mm
        elif estado["estado"] == "ESPERANDO_VISION":
            if time.ticks_diff(time.ticks_ms(), t_espera) > T_SIN_VISION_MS:
                estado["estado"] = "CLASIFICANDO"
                asyncio.create_task(clasificar(None))  # sin respuesta: a rechazo
            await asyncio.sleep_ms(50)
        else:
            await asyncio.sleep_ms(50)


def parsear(ruta):
    if "?" not in ruta:
        return ruta, {}
    camino, q = ruta.split("?", 1)
    args = {}
    for par in q.split("&"):
        if "=" in par:
            k, v = par.split("=", 1)
            args[k] = v.replace("+", " ").replace("%20", " ")
    return camino, args


def manejar(ruta):
    camino, args = parsear(ruta)
    if camino == "/estado":
        return "200 OK", resumen()
    if camino == "/moneda":
        if estado["estado"] != "ESPERANDO_VISION":
            return "409 Conflict", {"error": "no hay moneda esperando", "estado": estado["estado"]}
        try:
            valor = int(args.get("valor", "0"))
        except ValueError:
            valor = None
        estado["estado"] = "CLASIFICANDO"
        asyncio.create_task(clasificar(valor if valor in PESOS else None))
        return "200 OK", {"ok": True, "valor": valor}
    if camino == "/entregar":
        if ocupado:
            return "409 Conflict", {"error": "ocupada", "estado": estado["estado"]}
        try:
            valor = int(args.get("valor", "0"))
        except ValueError:
            valor = 0
        if valor not in PESOS:      # sin valor: el vaso con mas dinero
            valor = max(PESOS, key=lambda v: estado["vasos"][str(v)]["valor"])
        estado["estado"] = "ENTREGANDO"
        asyncio.create_task(entregar(valor))
        return "200 OK", {"ok": True, "vaso": valor, "contenido": estado["vasos"][str(valor)]}
    if camino == "/home":
        asyncio.create_task(hacer_home())
        return "200 OK", {"ok": True}
    if camino == "/tara":
        balanza.tara()
        return "200 OK", {"ok": True}
    return "404 Not Found", {"rutas": ["/estado", "/moneda?valor=", "/entregar?valor=", "/home", "/tara"]}


async def atender(lector, escritor):
    try:
        linea = await lector.readline()
        partes = linea.decode().split(" ")
        ruta = partes[1] if len(partes) > 1 else "/"
        while True:                                   # descartar cabeceras
            h = await lector.readline()
            if not h or h == b"\r\n":
                break
        codigo, cuerpo = manejar(ruta)
        escritor.write(("HTTP/1.1 %s\r\nContent-Type: application/json\r\n"
                        "Access-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n" % codigo).encode())
        escritor.write(json.dumps(cuerpo).encode())
        await escritor.drain()
    except Exception as e:
        print("HTTP error:", e)
    finally:
        escritor.close()
        await escritor.wait_closed()


def conectar_wifi():
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    if WIFI_SSID != "MI_RED":
        sta.connect(WIFI_SSID, WIFI_CLAVE)
        t0 = time.ticks_ms()
        while not sta.isconnected() and time.ticks_diff(time.ticks_ms(), t0) < 10000:
            time.sleep_ms(200)
    if sta.isconnected():
        return sta.ifconfig()[0]
    ap = network.WLAN(network.AP_IF)            # modo punto de acceso
    ap.active(True)
    ap.config(essid=AP_SSID, password=AP_CLAVE)
    return ap.ifconfig()[0]


async def principal():
    estado["ip"] = conectar_wifi()
    print("Estacion lista en http://%s/estado" % estado["ip"])
    balanza.tara()
    await asyncio.start_server(atender, "0.0.0.0", 80)
    await tarea_banda()


asyncio.run(principal())
